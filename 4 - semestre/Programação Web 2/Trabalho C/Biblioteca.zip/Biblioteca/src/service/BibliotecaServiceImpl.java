package service;
import model.Autor;
import model.Livro;
import java.util.*;
import javax.jws.WebService;

@WebService(endpointInterface = "service.BibliotecaService")
public class BibliotecaServiceImpl implements BibliotecaService {

    private Map<Integer, Autor> autores = new HashMap<>();
    private Map<Integer, Livro> livros = new HashMap<>();

    @Override
    public Autor criarAutor(Autor autor) {
        autores.put(autor.getId(), autor);
        return autor;
    }

    @Override
    public Autor buscarAutor(int id) {
        return autores.get(id);
    }

    @Override
    public List<Autor> listarAutores() {
        return new ArrayList<>(autores.values());
    }

    @Override
    public boolean removerAutor(int id) {
        return autores.remove(id) != null;
    }

    @Override
    public Livro criarLivro(Livro livro) {
        livros.put(livro.getId(), livro);
        return livro;
    }

    @Override
    public Livro buscarLivro(int id) {
        return livros.get(id);
    }

    @Override
    public List<Livro> listarLivros() {
        return new ArrayList<>(livros.values());
    }

    @Override
    public boolean removerLivro(int id) {
        return livros.remove(id) != null;
    }
}
