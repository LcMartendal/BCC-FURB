package service;

public class ServiceException extends Exception {
    private static final long serialVersionUID = 1L;
    private final String faultInfo;

    public ServiceException(String message) {
        super(message);
        this.faultInfo = message;
    }

    public ServiceException(String message, String faultInfo) {
        super(message);
        this.faultInfo = faultInfo;
    }

    public String getFaultInfo() { return faultInfo; }
}
