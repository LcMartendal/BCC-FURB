package service;
import model.Autor;
import model.Livro;
import java.util.List;
import javax.jws.WebMethod;
import javax.jws.WebService;

@WebService
public interface BibliotecaService {

    // Métodos para Autor
    @WebMethod Autor criarAutor(Autor autor);
    @WebMethod Autor buscarAutor(int id);
    @WebMethod List<Autor> listarAutores();
    @WebMethod boolean removerAutor(int id);

    // Métodos para Livro
    @WebMethod Livro criarLivro(Livro livro);
    @WebMethod Livro buscarLivro(int id);
    @WebMethod List<Livro> listarLivros();
    @WebMethod boolean removerLivro(int id);
}
