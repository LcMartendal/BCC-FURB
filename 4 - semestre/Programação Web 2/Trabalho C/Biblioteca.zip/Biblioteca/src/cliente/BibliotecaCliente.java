package cliente;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

import model.Autor;
import model.Livro;
import service.BibliotecaService;

import java.net.URL;
import java.util.List;
import java.util.logging.Logger;

public class BibliotecaCliente {
    private static final Logger logger = Logger.getLogger("BibliotecaCliente");

    public static void main(String[] args) throws Exception {
        URL wsdl = new URL("http://localhost:8080/BibliotecaService?wsdl");
        QName qname = new QName("http://service/", "BibliotecaServiceImplService");

        Service service = Service.create(wsdl, qname);
        BibliotecaService port = service.getPort(BibliotecaService.class);

        Autor a = new Autor();
        a.setId(1);
        a.setNome("Machado de Assis");
        a.setEmail("machado@literatura.com");
        port.criarAutor(a);

        Livro l = new Livro();
        l.setId(101);
        l.setTitulo("Dom Casmurro");
        l.setIsbn("1234567890");
        l.setAno(1899);
        port.criarLivro(l);

        logger.info("Autores cadastrados:");
        List<Autor> autores = port.listarAutores();
        for (Autor au : autores) logger.info(" - " + au.getNome());

        logger.info("Livros cadastrados:");
        List<Livro> livros = port.listarLivros();
        for (Livro li : livros) logger.info(" - " + li.getTitulo());
    }
}
