package Lista10.questao02;
import static org.junit.Assert.assertArrayEquals;

import org.junit.Test;

import Lista10.questao01.OrdenacaoBolha;
import Lista10.questao01.OrdenacaoBolhaOtimizada;
import Lista10.questao01.OrdenacaoMergeSort;
import Lista10.questao01.OrdenacaoQuickSort;

public class TesteOrdenacao {
    @Test
    public void teste01(){
        Integer[] dados = {70, 2, 88, 15, 90, 30};
        OrdenacaoBolha<Integer> bolha = new OrdenacaoBolha<>();
        bolha.setInfo(dados);
        bolha.ordenar();

        Integer[] esperado = {2, 15, 30, 70, 88, 90};
        assertArrayEquals(esperado, bolha.getInfo());
    }
    @Test
    public void teste02(){
        Integer[] dados = {70, 2, 88, 15, 90, 30};
        OrdenacaoBolhaOtimizada<Integer> bolhaOpt = new OrdenacaoBolhaOtimizada<>();
        bolhaOpt.setInfo(dados);
        bolhaOpt.ordenar();

        Integer[] esperado = {2, 15, 30, 70, 88, 90};
        assertArrayEquals(esperado, bolhaOpt.getInfo());
    }
    @Test
    public void teste03(){
        Integer[] dados = {70, 2, 88, 15, 90, 30};
        OrdenacaoQuickSort<Integer> quickSort = new OrdenacaoQuickSort<>();
        quickSort.setInfo(dados);
        quickSort.ordenar();

        Integer[] esperado = {2, 15, 30, 70, 88, 90};
        assertArrayEquals(esperado, quickSort.getInfo());
    }
    @Test
public void teste04() {
    Integer[] dados = {70, 2, 88, 15, 90, 30};
    OrdenacaoMergeSort<Integer> merge = new OrdenacaoMergeSort<>();
    merge.setInfo(dados);
    merge.ordenar();

    Integer[] esperado = {2, 15, 30, 70, 88, 90};
    assertArrayEquals(esperado, merge.getInfo());
}
}
