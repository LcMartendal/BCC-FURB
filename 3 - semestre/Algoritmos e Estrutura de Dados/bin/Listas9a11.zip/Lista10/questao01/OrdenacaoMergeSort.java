package Lista10.questao01;

public class OrdenacaoMergeSort <T extends Comparable<T>> extends OrdenacaoAbstract<T>{

    @Override
    public void ordenar() {
        mergeSort(0, getInfo().length - 1);
    }

    private void mergeSort(int inicio, int fim) {
        if (inicio < fim) {
            int meio = (inicio + fim) / 2;
            mergeSort(inicio, meio);
            mergeSort(meio + 1, fim);
            merge(inicio, fim, meio);
        }
    }

    @SuppressWarnings("unchecked")
    private void merge(int inicio, int fim, int meio) {
        T[] vetor = getInfo();

        int tamEsquerda = meio - inicio + 1;
        T[] esquerda = (T[]) new Comparable[tamEsquerda];
        for (int i = 0; i < tamEsquerda; i++) {
            esquerda[i] = vetor[inicio + i];
        }
        
        int tamDireita = fim - meio;
        T[] direita = (T[]) new Comparable[tamDireita];
        for (int i = 0; i < tamDireita; i++) {
            direita[i] = vetor[meio + 1 + i];
        }

        int cEsq = 0;
        int cDir = 0;
        int i = inicio;

        // Mescla os dois vetores de forma ordenada
        while (cEsq < tamEsquerda && cDir < tamDireita) {
            if (esquerda[cEsq].compareTo(direita[cDir]) <= 0) {
                vetor[i++] = esquerda[cEsq++];
            } else {
                vetor[i++] = direita[cDir++];
            }
        }

        // Copia os elementos restantes (se houver)
        while (cEsq < tamEsquerda) {
            vetor[i++] = esquerda[cEsq++];
        }

        while (cDir < tamDireita) {
            vetor[i++] = direita[cDir++];
        }
    }
    
}