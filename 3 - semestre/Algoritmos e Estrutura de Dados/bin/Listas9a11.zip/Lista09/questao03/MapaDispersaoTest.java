package Lista09.questao03;
import static org.junit.Assert.assertEquals;

import java.time.LocalDate;

import org.junit.Test;

import Lista09.questao01.MapaDispersao;
import Lista09.questao02.Aluno;

public class MapaDispersaoTest {
    @Test
    public void teste01() {
        MapaDispersao<Aluno> mapa = new MapaDispersao<>(53);

        Aluno aluno01 = new Aluno(12000, "Jean", LocalDate.of(2000, 01, 01));
        mapa.inserir(12000, aluno01);

        assertEquals(aluno01, mapa.buscar(12000));
    }

    @Test
    public void teste02() {
        MapaDispersao<Aluno> mapa = new MapaDispersao<>(53);
        
        Aluno aluno01 = new Aluno(12000, "Jean", LocalDate.of(2000, 01, 01));
        mapa.inserir(12000, aluno01);
        Aluno aluno02 = new Aluno(14000, "Pedro", LocalDate.of(1999, 01, 20));
        mapa.inserir(14000, aluno02);
        Aluno aluno03 = new Aluno(12500, "Marta", LocalDate.of(2000, 02, 18));
        mapa.inserir(12500, aluno03);
        Aluno aluno04 = new Aluno(13000, "Lucas", LocalDate.of(1998, 11, 25));
        mapa.inserir(13000, aluno04);

        assertEquals(aluno01, mapa.buscar(12000));
        assertEquals(aluno02, mapa.buscar(14000));
        assertEquals(aluno03, mapa.buscar(12500));
        assertEquals(aluno04, mapa.buscar(13000));
    }

    @Test
    public void teste03() {
        MapaDispersao<Aluno> mapa = new MapaDispersao<>(53);
        
        Aluno aluno01 = new Aluno(12000, "Jean", LocalDate.of(2000, 01, 01));
        mapa.inserir(12000, aluno01);
        Aluno aluno02 = new Aluno(14000, "Pedro", LocalDate.of(1999, 01, 20));
        mapa.inserir(14000, aluno02);
        Aluno aluno03 = new Aluno(14226, "Marta", LocalDate.of(2000, 02, 18));
        mapa.inserir(14226, aluno03);
        Aluno aluno04 = new Aluno(17180, "Lucas", LocalDate.of(1998, 11, 25));
        mapa.inserir(17180, aluno04);

        assertEquals(aluno01, mapa.buscar(12000));
        assertEquals(aluno02, mapa.buscar(14000));
        assertEquals(aluno03, mapa.buscar(14226));
        assertEquals(aluno04, mapa.buscar(17180));

        mapa.remover(17180);
        assertEquals(null, mapa.buscar(17180));

    }
}
