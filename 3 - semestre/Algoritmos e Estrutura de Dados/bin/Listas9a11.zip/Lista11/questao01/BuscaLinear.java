package Lista11.questao01;

public class BuscaLinear<T> extends BuscaAbstract{
    public int buscar(T valor) {
        for(int i=0;i<getInfo().length; i++) {
            if(getInfo()[i] == valor){
                return i;
            }
        }
        return -1;
    }
}
