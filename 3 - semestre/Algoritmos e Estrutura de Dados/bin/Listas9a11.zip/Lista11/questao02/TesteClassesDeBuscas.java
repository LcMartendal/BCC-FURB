package Lista11.questao02;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import Lista11.questao01.BuscaBinaria;
import Lista11.questao01.BuscaLinear;
import Lista11.questao01.BuscaLinearVetorOrdenado;
public class TesteClassesDeBuscas {

    @Test
    public void teste01() {
        BuscaLinear<Integer> busca = new BuscaLinear<>();

        Integer[] listaInteiros = {0,10,20,30,40,50,60,70,80,90,100};
        busca.setInfo(listaInteiros);

        assertEquals(2, busca.buscar(20));
    }

    @Test
    public void teste02(){
        BuscaLinearVetorOrdenado<Integer> busca = new BuscaLinearVetorOrdenado<>();

        Integer[] listaInteiros = {0,10,20,30,40,50,60,70,80,90,100};
        busca.setInfo(listaInteiros);

        assertEquals(4, busca.buscar(40));
    }

    @Test
    public void teste03(){
        BuscaBinaria<Integer> busca = new BuscaBinaria<>();

        Integer[] listaInteiros = {0,10,20,30,40,50,60,70,80,90,100};
        busca.setInfo(listaInteiros);

        assertEquals(7, busca.buscar(70));
    }

    @Test public void teste04(){
        BuscaBinaria<Integer> busca = new BuscaBinaria<>();

        Integer[] listaInteiros = {0,10,20,30,40,50,60,70,80,90,100};
        busca.setInfo(listaInteiros);

        assertEquals(-1, busca.buscar(75));
    }
}
