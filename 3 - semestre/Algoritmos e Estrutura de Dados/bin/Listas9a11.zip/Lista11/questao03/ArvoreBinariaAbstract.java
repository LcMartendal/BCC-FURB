package Lista11.questao03;

public abstract class ArvoreBinariaAbstract<T> {
    private NoArvoreBinaria<T> raiz;

    public ArvoreBinariaAbstract(){
        raiz = null;
    }
    //------------metodos alterados/criados-------------

    public abstract NoArvoreBinaria<T> buscar(T info);

    protected void setRaiz(NoArvoreBinaria<T> raiz) {
        this.raiz = raiz;
    }

    public NoArvoreBinaria<T> getRaiz() {
        return raiz;
    }    

    public boolean pertence(T info){
        return buscar(info) != null;
    }

    //----------------------------------------

    public boolean estaVazia(){
        return raiz == null;
    }

    public String toString(){
        return arvorePre(raiz);
    }

    private String arvorePre(NoArvoreBinaria<T> no){
        String retorno = "";

        if(no == null){
            retorno+= "<>";
        }else{
            retorno+= "<" + no.getInfo() + arvorePre(no.getEsquerda()) + arvorePre(no.getDireita()) + ">";
        }
        return retorno;
    }

    public int contarNos(){
        return contarNos(raiz);
    }

    private int contarNos(NoArvoreBinaria<T> no){
        int qtdnos = 0;
        if(no != null){
            qtdnos = 1 + contarNos(no.getEsquerda()) + contarNos(no.getDireita());
        }

        return qtdnos;
    }
}
