package Lista04.teste;
import org.junit.Assert;
import org.junit.Test;

import Lista04.questao01.ListaDupla;

public class ListaDuplaTest {
    @Test
    public void testInserir() {
        ListaDupla<String> lista = new ListaDupla<>();
        lista.inserir(new String("5"));
        lista.inserir(new String("10"));
        lista.inserir(new String("15"));
        lista.inserir(new String("20"));

        Assert.assertEquals("20,15,10,5", lista.toString());
        
    }

    @Test
    public void testExibirOrdemInversa() {

    }

    @Test
    public void testGetPrimeiro() {

    }

    @Test
    public void testInserir02() {

    }

    @Test
    public void testLiberar() {

    }

    @Test
    public void testRetirar() {

    }

    @Test
    public void testToString() {

    }
}
