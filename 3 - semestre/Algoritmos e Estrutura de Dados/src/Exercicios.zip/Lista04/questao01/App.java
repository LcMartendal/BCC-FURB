package Lista04.questao01;

public class App {
    public static void main(String[] args) {
        ListaDupla<Integer> lista = new ListaDupla<>();

        /*[20,49,15,29,81 */
        lista.inserir(20);
        lista.inserir(49);
        lista.inserir(15);
        lista.inserir(29);
        lista.inserir(81);

        ListaDupla<Integer> lista2 = new ListaDupla<>();

        System.out.println(lista.toString());
        lista2 = lista.criarSubLista(3, 4);
        
        System.out.println(lista2.toString());
    }
}
