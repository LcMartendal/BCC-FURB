package Lista04.questao01;

public class ListaDupla<T> {
    private NoListaDupla<T> primeiro;

    public ListaDupla(){
        this.primeiro = null;
    }

    public NoListaDupla<T> getPrimeiro(){
        return this.primeiro;
    }

    public ListaDupla<T> criarSubLista(int inicio, int fim){
        ListaDupla<T> sub = new ListaDupla<>();
        NoListaDupla<T> p = this.primeiro;

        if(inicio <= -1 || fim <= -1 ){
            throw new IndexOutOfBoundsException();
        }
        for(int i = 1; i <= fim ; i++){
            if(i >= inicio){
                sub.inserir(p.getInfo());
                p = p.getProximo();
            }else{
                p = p.getProximo();
            }
            
        }

        return sub;
    }


    public void inserir(T valor){
        NoListaDupla<T> novo = new NoListaDupla<>();
        novo.setInfo(valor);
        novo.setProximo(this.primeiro);
        novo.setAnterior(null);
        if(primeiro != null){
            this.primeiro.setAnterior(novo);
        }
        this.primeiro = novo;
    }

    public NoListaDupla<T> buscar(T valor){
        NoListaDupla<T> p = this.primeiro;

        while(p!=null){
            if(p.getInfo().equals(valor)){
                return p;
            }
            p = p.getProximo();
        }
        return null;
    }

    public void retirar(T valor){
        NoListaDupla<T> p = buscar(valor);

        if(p!=null){
            if(primeiro.equals(p)){
                primeiro = p.getProximo();
            }else {
                p.getAnterior().setProximo(p.getProximo());
            }
        }

        if(p.getProximo() != null){
            p.getProximo().setAnterior(p.getAnterior());
        }
    }

    private NoListaDupla<T> obterUltimoNo(){
        NoListaDupla<T> ultimo = this.primeiro;
        NoListaDupla<T> p = this.primeiro;
        while(p != null){
            ultimo = p;
            p = p.getProximo();
        }

        return ultimo;
    }

    public void exibirOrdemInversa1(){
        NoListaDupla<T> p = obterUltimoNo();

        while(p!=null){
            System.out.println(p.getInfo());
            p = p.getAnterior();
        }
    }

    //ou

    public void exibirOrdemInversa2(){
        NoListaDupla<T> p = this.primeiro;
        NoListaDupla<T> ultimoNO = null;
        while (p != null) {
            ultimoNO = p;
            p = p.getProximo();
        }
        while(ultimoNO!=null){
            System.out.println(ultimoNO.getInfo());
            ultimoNO = ultimoNO.getAnterior();
        }
    }

    public void liberar(){
        NoListaDupla<T> p = this.primeiro;

        while(p!=null){
            p.setAnterior(null);
            NoListaDupla<T> guardaProximo = p.getProximo();
            p.setProximo(null);
            
            p = guardaProximo;
        }
    }

    

    public String toString() {
        String msg = "";
        NoListaDupla<T> p = primeiro;

        while(p!=null){
            if(p!=primeiro){
                msg+= ",";
            }
            msg+= p.getInfo();
            p = p.getProximo();
        }

        return msg;
    }

}
