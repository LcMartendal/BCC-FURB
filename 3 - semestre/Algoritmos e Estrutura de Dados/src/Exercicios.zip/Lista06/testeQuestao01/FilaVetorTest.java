package Lista06.testeQuestao01;
import static org.junit.Assert.assertEquals;

import org.junit.Test;

import Lista06.questao01.FilaCheioException;
import Lista06.questao01.FilaVaziaException;
import Lista06.questao01.FilaVetor;

public class FilaVetorTest {
    @Test
    public void test01() {
        FilaVetor<Integer> fila = new FilaVetor<>(10);
        
        assertEquals(true, fila.estaVazia());
    }

    @Test
    public void test02() {
        FilaVetor<Integer> fila = new FilaVetor<>(10);
        fila.inserir(10);

        assertEquals(false, fila.estaVazia());
    }

    @Test
    public void test03() {
        FilaVetor<Integer> fila = new FilaVetor<>(10);
        fila.inserir(10);
        fila.inserir(20);
        fila.inserir(30);
        
        assertEquals(10, fila.retirar().intValue());
        assertEquals(20, fila.retirar().intValue());
        assertEquals(30, fila.retirar().intValue());
        assertEquals(true, fila.estaVazia());
    }

    @Test(expected = FilaCheioException.class)
    public void test04() {
        FilaVetor<Integer> fila = new FilaVetor<>(3);
        fila.inserir(10);
        fila.inserir(20);
        fila.inserir(30);
        fila.inserir(40);
    }

    @Test(expected = FilaVaziaException.class)
    public void test05() {
        FilaVetor<Integer> fila = new FilaVetor<>(10);
        fila.retirar();
    }

    @Test
    public void test06() {
        FilaVetor<Integer> fila = new FilaVetor<>(5);
        fila.inserir(10);
        fila.inserir(20);
        fila.inserir(30);

        assertEquals(10, fila.peek().intValue());
        assertEquals(10, fila.retirar().intValue());
    }

    @Test
    public void test07() {
        FilaVetor<Integer> fila = new FilaVetor<>(5);
        fila.inserir(10);
        fila.inserir(20);
        fila.inserir(30);
        fila.liberar();

        assertEquals(true, fila.estaVazia());
    }

    @Test
    public void test08() {
        FilaVetor<Integer> fila1 = new FilaVetor<>(5);
        fila1.inserir(10);
        fila1.inserir(20);
        fila1.inserir(30);

        FilaVetor<Integer> fila2 = new FilaVetor<>(3);
        fila2.inserir(40);
        fila2.inserir(50);

        FilaVetor<Integer> fila3 = new FilaVetor<>(8);
        fila3 = fila1.criarFilaConcatenada(fila2);

        
        assertEquals("10,20,30,40,50", fila3.toString());
        assertEquals("10,20,30", fila1.toString());
        assertEquals("40,50", fila2.toString());
        assertEquals(8, fila3.getLimite());
    }
}
