package Lista06.questao02;

public class FilaCheioException extends RuntimeException {

}
