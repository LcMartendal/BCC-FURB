package Lista06.questao02;

public class app {
    public static void main(String[] args) {
        FilaLista<Integer> fila = new FilaLista<>();

        fila.inserir(80);
        fila.inserir(99);
        System.out.println(fila.toString());
        fila.liberar();
        System.out.println(fila.toString());
    }
}
