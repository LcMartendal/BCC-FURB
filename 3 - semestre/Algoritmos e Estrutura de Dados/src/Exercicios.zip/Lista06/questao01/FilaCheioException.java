package Lista06.questao01;

public class FilaCheioException extends RuntimeException {

}
