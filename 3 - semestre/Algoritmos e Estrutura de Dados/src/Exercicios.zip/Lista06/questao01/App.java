package Lista06.questao01;

public class App {
    public static void main(String[] args) {
        
        /*
        FilaVetor<Integer> fila1 = new FilaVetor<>(50);

        for(int i=1;i<50;i+=2){
            fila1.inserir(i);
        }
        FilaVetor<Integer> fila2 = new FilaVetor<>(50);

        for(int i=0;i<=50;i+=2){
            fila2.inserir(i);
        }

        FilaVetor<Integer> fila3 = new FilaVetor<>(100);

        fila3 = fila1.criarFilaConcatenada(fila2);

        System.out.println(fila3.toString());
        */

        FilaVetor<Integer> fila1 = new FilaVetor<>(5);
        fila1.inserir(10);
        fila1.inserir(20);
        fila1.inserir(30);
        fila1.retirar();

        

        FilaVetor<Integer> fila2 = new FilaVetor<>(3);
        fila2.inserir(40);
        fila2.inserir(50);

        FilaVetor<Integer> fila3 = new FilaVetor<>(8);
        fila3 = fila1.criarFilaConcatenada(fila2);

        System.out.println(fila3.toString());
    }
}
