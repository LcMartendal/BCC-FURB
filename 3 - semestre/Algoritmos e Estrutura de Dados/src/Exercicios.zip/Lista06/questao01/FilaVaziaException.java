package Lista06.questao01;

public class FilaVaziaException extends RuntimeException {

}
