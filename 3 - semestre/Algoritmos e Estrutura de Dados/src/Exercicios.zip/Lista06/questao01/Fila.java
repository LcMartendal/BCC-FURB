package Lista06.questao01;

public interface Fila<T> {
    void inserir(T valor);
    T retirar();
    T peek();
    boolean estaVazia();
    void liberar();
}
