package Lista06.questao01;

public class FilaVetor<T> implements Fila<T> {
    private Object info[];
    private int limite;
    private int tamanho;
    private int inicio;

    public FilaVetor(int limite){
        this.info = new Object[limite];
        this.limite = limite;
        this.tamanho = 0;
        this.inicio = 0;
    }

    @Override
    public void inserir(T valor) {
        if(tamanho == limite){
            throw new FilaCheioException();
        }

        int posicaoInserir = (tamanho + inicio) % limite;
        info[posicaoInserir] = valor;
        tamanho++;
    }

    @Override
    public T retirar() {
        T valor = peek();
        this.info[this.inicio] = null;
        this.inicio = (this.inicio + 1) % this.limite;
        tamanho--;

        return valor;
    }

    @SuppressWarnings("unchecked")
    @Override
    public T peek() {
        if(estaVazia()){
            throw new FilaVaziaException();
        }

        return (T) this.info[inicio];
    }

    @Override
    public boolean estaVazia() {
        return tamanho == 0;
    }

    @Override
    public void liberar() {
        /*for(int i=0;i<tamanho;i++){
            this.info[i] = null;
        }
        this.inicio = 0;
        tamanho = 0;*/

        info = new Object[limite];
        tamanho = 0;
    } 

    @SuppressWarnings("unchecked")
    public FilaVetor<T> criarFilaConcatenada(FilaVetor<T> f2){

        /* 
            FilaVetor<T> nova = new FilaVetor<>(this.limite + f2.limite);

        for(int i=0;i<this.tamanho;i++){
            if(this.inicio == this.limite){
                i = 0;
                
            }
            nova.inserir((T) this.info[inicio + i]);
        }
        for(int i=0;i<f2.tamanho;i++){
            if(f2.inicio == f2.limite){
                i = 0;
                
            }
            nova.inserir((T) f2.info[inicio + i]);
        }
        
        nova.limite = f2.getLimite() + this.getLimite();
        return nova;
        */

        FilaVetor<T> f3 = new FilaVetor<>(this.limite + f2.limite);

        int posicao = this.inicio;
        for(int i=0;i<this.tamanho;i++){
            f3.inserir((T) this.info[posicao]);
            posicao = (posicao + 1) % this.limite;
        }
        
        posicao = f2.inicio;
        for(int i=0;i<f2.tamanho;i++){
            f3.inserir((T) f2.info[posicao]);
            posicao = (posicao + 1) % this.limite;
        }

        return f3;
    }

    public String toString(){
        String retorno = "";

        int posicao = inicio;

        for(int i=0; i<tamanho;i++){
            if(i > 0){
                retorno += ",";
            }

            retorno = retorno + info[posicao];
            posicao = (posicao + 1) % limite;
        }

        return retorno;

        /*
        String res = "";

        for(int i=this.inicio;i<=this.tamanho;i++){
            
            if(this.inicio == this.limite){
                i = 0;
                if(i == inicio){
                    i = tamanho;
                }
            }

            if(this.info[i] != null){
                if(res != ""){
                    res+= ",";
                }
    
                res+= this.info[i];
            }
        }

        return res;
        */
    }

    public int getLimite(){
        return this.limite;
    }

    

}
