package Lista01.testeQuestao01;

import org.junit.Assert;
import org.junit.Test;

import Lista01.questao01.ListaEstatica;

public class ListaEstaticaTest {

    ListaEstatica le = new ListaEstatica();;
    @Test
    public void testInserir01() {
        le.inserir(5);
        le.inserir(10);
        le.inserir(15);
        le.inserir(20);

        Assert.assertEquals("5,10,15,20", le.toString());
    }

    @Test
    public void testTamanhoLista01() {
        le.inserir(5);
        le.inserir(10);
        le.inserir(15);
        le.inserir(20);

        Assert.assertEquals(4, le.getTamanho());
    }

    @Test
    public void testExisteElemento01() {
        le.inserir(5);
        le.inserir(10);
        le.inserir(15);
        le.inserir(20);

        Assert.assertEquals(2, le.buscar(15));
    }

    @Test
    public void testExisteElemento02() {
        le.inserir(5);
        le.inserir(10);
        le.inserir(15);
        le.inserir(20);

        Assert.assertEquals(-1, le.buscar(30));
    }

    @Test
    public void testRetirar01() {
        le.inserir(5);
        le.inserir(10);
        le.inserir(15);
        le.inserir(20);
        
        le.retirar(10);

        Assert.assertEquals("5,15,20", le.toString());
        Assert.assertEquals(3, le.getTamanho());

    }

    @Test
    public void testRedimensionar01() {
        le.inserir(1);
        le.inserir(2);
        le.inserir(3);
        le.inserir(4);
        le.inserir(5);
        le.inserir(6);
        le.inserir(7);
        le.inserir(8);
        le.inserir(9);
        le.inserir(10);
        le.inserir(11);
        le.inserir(12);
        le.inserir(13);
        le.inserir(14);
        le.inserir(15);

        Assert.assertEquals("1,2,3,4,5,6,7,8,9,10,11,12,13,14,15", le.toString());
        Assert.assertEquals(15, le.getTamanho());
        
    }

    @Test
    public void testObterElemento01() {
        le.inserir(5);
        le.inserir(10);
        le.inserir(15);
        le.inserir(20);

        Assert.assertEquals(20, le.obterElemento(3));
    }

    @Test(expected =  IndexOutOfBoundsException.class)
    public void testObterElemento02() {
        le.inserir(5);
        le.inserir(10);
        le.inserir(15);
        le.inserir(20);

        le.obterElemento(5);

        /*
        try{
            lista.obterElemento(5);
            fail();
        }catch(IndexOutOfBoundsException e){
            //se recusou obterElemento(5)
        }
        */
    }

    @Test
    public void testLiberar01() {
        le.inserir(5);
        le.inserir(10);
        le.inserir(15);
        le.inserir(20);

        le.libera();

        Assert.assertEquals(true, le.estaVazia());
    }
}
