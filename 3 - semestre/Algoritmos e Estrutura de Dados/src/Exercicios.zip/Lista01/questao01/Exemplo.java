package Lista01.questao01;

public class Exemplo {
    public static void main(String[] args) {
        ListaEstatica lista = new ListaEstatica();

        lista.inserir(55);
        lista.inserir(66);
        lista.inserir(77);

        //lista.buscar(66);

        //System.out.println(lista.buscar(66));
        //lista.exibir();
        System.out.println(lista.toString());
        lista.buscar(9);
    }
}
