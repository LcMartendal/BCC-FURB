package Lista05.testeQuestao02;
import static org.junit.Assert.assertEquals;

import org.junit.Test;

import Lista05.questao02.PilhaLista;

public class PilhaListaTest {

    @Test
    public void test01() {
        PilhaLista<Integer> pilha = new PilhaLista<>();

        assertEquals(true, pilha.estaVazia());
    }

    @Test
    public void test02() {
        PilhaLista<Integer> pilha = new PilhaLista<>();
        pilha.push(10);

        assertEquals(false, pilha.estaVazia());
    }

    @Test
    public void test03() {
        PilhaLista<Integer> pilha = new PilhaLista<>();
        pilha.push(10);
        pilha.push(20);
        pilha.push(30);


        assertEquals(30, pilha.pop().intValue());
        assertEquals(20, pilha.pop().intValue());
        assertEquals(10, pilha.pop().intValue());
        assertEquals(true, pilha.estaVazia());

    }

    @Test
    public void test04() {
        PilhaLista<Integer> pilha = new PilhaLista<>();
        pilha.push(10);
        pilha.push(20);
        pilha.push(30);

        assertEquals(30, pilha.peek().intValue());
        assertEquals(30, pilha.pop().intValue());
    }

    @Test
    public void test05() {
        PilhaLista<Integer> pilha = new PilhaLista<>();
        pilha.push(10);
        pilha.push(20);
        pilha.push(30);
        pilha.liberar();

        assertEquals(true, pilha.estaVazia());

    }

    @Test
    public void testToString() {

    }
}
