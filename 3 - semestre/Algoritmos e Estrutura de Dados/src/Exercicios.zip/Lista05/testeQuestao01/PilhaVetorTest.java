package Lista05.testeQuestao01;
import org.junit.Assert;
import org.junit.Test;

import Lista05.questao01.PilhaCheioException;
import Lista05.questao01.PilhaVaziaException;
import Lista05.questao01.PilhaVetor;

public class PilhaVetorTest {
    @Test
    public void test01() {
        PilhaVetor<Integer> pilha = new PilhaVetor<>(10);

        Assert.assertEquals(true, pilha.estaVazia());
    }

    @Test
    public void test02() {
        PilhaVetor<Integer> pilha = new PilhaVetor<>(5);

        pilha.push(10);
        Assert.assertEquals(false, pilha.estaVazia());
    }

    @Test
    public void test03() {
        PilhaVetor<Integer> pilha = new PilhaVetor<>(10);
        pilha.push(10);
        pilha.push(20);
        pilha.push(30);
        pilha.push(40);

        pilha.pop();
        Assert.assertEquals(30, pilha.peek().intValue());
        pilha.pop();
        Assert.assertEquals(20, pilha.peek().intValue());
        pilha.pop();
        Assert.assertEquals(10, pilha.peek().intValue());
        pilha.pop();
        Assert.assertEquals(true, pilha.estaVazia());
    }

    @Test(expected = PilhaCheioException.class)
    public void test04() {
        PilhaVetor<Integer> pilha = new PilhaVetor<>(3);
        pilha.push(10);
        pilha.push(20);
        pilha.push(30);
        pilha.push(40);

    }

    @Test(expected = PilhaVaziaException.class)
    public void test05() {
        PilhaVetor<Integer> pilha = new PilhaVetor<>(0);
        pilha.pop();
    }

    @Test
    public void test06() {
        PilhaVetor<Integer> pilha = new PilhaVetor<>(5);
        pilha.push(10);
        pilha.push(20);
        pilha.push(30);

        Assert.assertEquals(30, pilha.peek().intValue());
        Assert.assertEquals(30, pilha.pop().intValue());
    }

    @Test
    public void test07() {
        PilhaVetor<Integer> pilha = new PilhaVetor<>(5);
        pilha.push(10);
        pilha.push(20);
        pilha.push(30);

        pilha.liberar();

        Assert.assertEquals(true, pilha.estaVazia());
    }

    @Test
    public void test08() {
        PilhaVetor<Integer> pilha01 = new PilhaVetor<>(10);
        pilha01.push(10);
        pilha01.push(20);
        pilha01.push(30);

        PilhaVetor<Integer> pilha02 = new PilhaVetor<>(5);
        pilha02.push(40);
        pilha02.push(50);


        pilha01.concatenar(pilha02);

        Assert.assertEquals("50,40,30,20,10", pilha01.toString());
    }
}
