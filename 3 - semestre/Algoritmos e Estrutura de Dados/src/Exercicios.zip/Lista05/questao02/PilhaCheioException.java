package Lista05.questao02;

public class PilhaCheioException extends RuntimeException {

}
