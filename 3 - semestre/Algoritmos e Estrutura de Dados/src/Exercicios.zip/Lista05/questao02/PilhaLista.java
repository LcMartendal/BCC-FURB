package Lista05.questao02;

public class PilhaLista<T> implements Pilha<T> {

    ListaEncadeada<T> lista = new ListaEncadeada<>();

    @Override
    public void push(T info) {
        lista.inserir(info);
    }

    @Override
    public T pop() {
        T valor;
        valor = peek();
        lista.retirar(valor);

        return valor;
    }

    @Override
    public T peek() {
        if(this.estaVazia()){
            throw new PilhaVaziaException();
        }

        return lista.getPrimeiro().getInfo();
    }

    @Override
    public boolean estaVazia() {
        return lista.estaVazia();
    }

    @Override
    public void liberar() {
        lista = new ListaEncadeada<>();
    }

    public String toString(){
        return lista.toString();
    }

    public boolean validarBalanceamento(String expr){
        int cont1 = 0;
        int cont2 = 0;
        for(int i=0;i<expr.length();i++){
            if(expr.charAt(i) == '(' || expr.charAt(i) == '{' || expr.charAt(i) == '[' ){
                cont1++;
            }else if(expr.charAt(i) == ')' || expr.charAt(i) == '}' || expr.charAt(i) == ']' ){
                cont2++;
            }
        }

        if(cont1 == cont2){
            return true;
        }else{
            return false;
        }
    }

}
