package Lista05.questao02;

public class PilhaVaziaException extends RuntimeException {

}
