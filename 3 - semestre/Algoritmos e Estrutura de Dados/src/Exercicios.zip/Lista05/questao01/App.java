package Lista05.questao01;

public class App {

    public static void main(String[] args) {
        
        PilhaVetor<Integer> lista1 = new PilhaVetor<>(5);

        //System.out.println(lista1.getTamanho());
        lista1.push(5);
        lista1.push(6);
        //System.out.println(lista1.getTamanho());
        //System.out.println(lista1.toString());
        //System.out.println(lista1.peek());

        PilhaVetor<Integer> lista2 = new PilhaVetor<>(5);
        lista2.push(2);
        lista2.push(3);
        lista2.push(3);
        
      

        lista1.concatenar(lista2);
        System.out.println(lista1.getTamanho());
        System.out.println(lista1.toString());
    }
}
