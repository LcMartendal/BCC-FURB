package Lista05.questao01;

public class PilhaCheioException extends RuntimeException {

}
