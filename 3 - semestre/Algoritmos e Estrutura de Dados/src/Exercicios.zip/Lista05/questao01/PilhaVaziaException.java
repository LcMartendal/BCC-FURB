package Lista05.questao01;

public class PilhaVaziaException extends RuntimeException {

}
