package Lista05.questao01;

public class PilhaVetor<T> implements Pilha<T>{
    private int limite;
    private int tamanho;
    private Object[] info;

    public PilhaVetor(int limite){
        this.info = new Object[limite];
        this.limite = limite;
        this.tamanho = 0;
    }

    
    public int getTamanho() {
        return tamanho;
    }


    @Override
    public void push(T valor) {
        if(tamanho == limite){
            throw new PilhaCheioException();
        }
        this.info[tamanho] = valor;
        tamanho++;


    }

    @Override
    public T pop(){
        T valor = peek();
        this.info[tamanho-1] = null;
        this.tamanho--;

        return valor;

    }

    @SuppressWarnings("unchecked")
    @Override
    public T peek() {
        if(estaVazia() == true){
            throw new PilhaVaziaException();
        }
        
        return (T) this.info[tamanho - 1];
    }

    @Override
    public boolean estaVazia() {
        return tamanho == 0;
    }

    @Override
    public void liberar() {
        for(int i=0; i<tamanho; i++){
            this.info[i] = null;
        }

        this.tamanho = 0;
    }

    public String toString() {
        String resultado = "";

        for(int i=this.tamanho-1;i>=0;i--){
            resultado += this.info[i];
            if(i>0){
                resultado =  resultado + ",";
            }
        }

        return resultado;
    }

    @SuppressWarnings("unchecked")
    public void concatenar(PilhaVetor<T> p){
        if((this.tamanho + p.tamanho) > this.limite){
            throw new PilhaCheioException();
        }
        
        for(int i=0;i<p.tamanho;i++){
            this.push((T) p.info[i]);
        }       

    }
}
