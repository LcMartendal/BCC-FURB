package Lista08.testeQuestao01;
import static org.junit.Assert.assertEquals;

import org.junit.Assert;
import org.junit.Test;

import Lista08.questao01.Arvore;
import Lista08.questao01.NoArvore;

public class ArvoreTest {
    @Test
    public void test01() {

        NoArvore<Integer> no10 = new NoArvore<Integer>(10);
        NoArvore<Integer> no9 = new NoArvore<Integer>(9);
        NoArvore<Integer> no4 = new NoArvore<Integer>(4);
        no4.inserirFilhos(no10);
        no4.inserirFilhos(no9);

        NoArvore<Integer> no8 = new NoArvore<Integer>(8);
        NoArvore<Integer> no3 = new NoArvore<Integer>(3);
        no3.inserirFilhos(no8);

        NoArvore<Integer> no7 = new NoArvore<Integer>(7);
        NoArvore<Integer> no6 = new NoArvore<Integer>(6);
        NoArvore<Integer> no5 = new NoArvore<Integer>(5);
        NoArvore<Integer> no2 = new NoArvore<Integer>(2);
        no2.inserirFilhos(no7);
        no2.inserirFilhos(no6);
        no2.inserirFilhos(no5);

        NoArvore<Integer> no1 = new NoArvore<Integer>(1);
        no1.inserirFilhos(no4);
        no1.inserirFilhos(no3);
        no1.inserirFilhos(no2);

        Arvore<Integer> arvore = new Arvore<>();
        arvore.setRaiz(no1);

        Assert.assertEquals("<1<2<5><6><7>><3<8>><4<9><10>>>", arvore.toString());

    }

    @Test
    public void test2() {

    }

    @Test
    public void test3() {
        
    }

    @Test
    public void test4() {
        NoArvore<Integer> no10 = new NoArvore<Integer>(10);
        NoArvore<Integer> no9 = new NoArvore<Integer>(9);
        NoArvore<Integer> no4 = new NoArvore<Integer>(4);
        no4.inserirFilhos(no10);
        no4.inserirFilhos(no9);

        NoArvore<Integer> no8 = new NoArvore<Integer>(8);
        NoArvore<Integer> no3 = new NoArvore<Integer>(3);
        no3.inserirFilhos(no8);

        NoArvore<Integer> no7 = new NoArvore<Integer>(7);
        NoArvore<Integer> no6 = new NoArvore<Integer>(6);
        NoArvore<Integer> no5 = new NoArvore<Integer>(5);
        NoArvore<Integer> no2 = new NoArvore<Integer>(2);
        no2.inserirFilhos(no7);
        no2.inserirFilhos(no6);
        no2.inserirFilhos(no5);

        NoArvore<Integer> no1 = new NoArvore<Integer>(1);
        no1.inserirFilhos(no4);
        no1.inserirFilhos(no3);
        no1.inserirFilhos(no2);

        Arvore<Integer> arvore = new Arvore<>();
        arvore.setRaiz(no1);

        assertEquals(10, arvore.contarNos());
    }
}
