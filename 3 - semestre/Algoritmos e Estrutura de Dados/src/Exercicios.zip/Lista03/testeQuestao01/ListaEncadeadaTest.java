package Lista03.testeQuestao01;
import org.junit.Assert;
import org.junit.Test;

import Lista03.questao01.ListaEncadeada;


public class ListaEncadeadaTest {
    ListaEncadeada<String> lista ;

    @Test
    public void testEstaVazia() {
        lista = new ListaEncadeada<>();
        Assert.assertEquals(true, lista.estaVazia());
    }

    @Test
    public void testNaoEstaVazia() {
        lista = new ListaEncadeada<>();

        lista.inserir(new String("5"));
        Assert.assertEquals(false, lista.estaVazia());
    }

    @Test
    public void testIncluir01() {
        lista = new ListaEncadeada<>();
        lista.inserir(new String("5"));

        Assert.assertEquals("5", lista.getPrimeiro().getInfo());
    }

    @Test
    public void testIncluir02() {
        lista = new ListaEncadeada<>();
        lista.inserir(new String("5"));
        lista.inserir(new String("10"));
        lista.inserir(new String("15"));

        Assert.assertEquals("15, 10, 5", lista.toString());
        Assert.assertEquals(3, lista.obterComprimento());
    }

    @Test
    public void testBusca01() {
        lista = new ListaEncadeada<>();
        lista.inserir(new String("5"));
        lista.inserir(new String("10"));
        lista.inserir(new String("15"));
        lista.inserir(new String("20"));
        String resultado = lista.buscar("20").getInfo();
        Assert.assertEquals("20", resultado);
        
    }

    @Test
    public void testBusca02() {
        lista = new ListaEncadeada<>();
        lista.inserir(new String("5"));
        lista.inserir(new String("10"));
        lista.inserir(new String("15"));
        lista.inserir(new String("20"));
        String resultado = lista.buscar("15").getInfo();
        Assert.assertEquals("15", resultado);
    }

    @Test
    public void testBusca03() {
        lista = new ListaEncadeada<>();
        lista.inserir(new String("5"));
        lista.inserir(new String("10"));
        lista.inserir(new String("15"));
        lista.inserir(new String("20"));
        Assert.assertEquals(null, lista.buscar("50"));
    }

    @Test
    public void testExcluir01() {
        lista = new ListaEncadeada<>();
        lista.inserir(new String("5"));
        lista.inserir(new String("10"));
        lista.inserir(new String("15"));
        lista.inserir(new String("20"));
        lista.retirar("20");
        Assert.assertEquals("15, 10, 5", lista.toString());
    }

    @Test
    public void testExcluir02() {
        lista = new ListaEncadeada<>();
        lista.inserir(new String("5"));
        lista.inserir(new String("10"));
        lista.inserir(new String("15"));
        lista.inserir(new String("20"));
        lista.retirar("15");
        Assert.assertEquals("20, 10, 5", lista.toString());
    }

    @Test
    public void testObterNo01() {
        lista = new ListaEncadeada<>();
        lista.inserir(new String("5"));
        lista.inserir(new String("10"));
        lista.inserir(new String("15"));
        lista.inserir(new String("20"));
        Assert.assertEquals("20", lista.obterNo(0).getInfo());
    }

    @Test
    public void testObterNo02() {
        lista = new ListaEncadeada<>();
        lista.inserir(new String("5"));
        lista.inserir(new String("10"));
        lista.inserir(new String("15"));
        lista.inserir(new String("20"));
        Assert.assertEquals("5", lista.obterNo(3).getInfo());
    }

    @Test(expected = IndexOutOfBoundsException.class)
    public void testObterNo03() {
        lista = new ListaEncadeada<>();
        lista.inserir(new String("5"));
        lista.inserir(new String("10"));
        lista.inserir(new String("15"));
        lista.inserir(new String("20"));
        Assert.assertEquals("20", lista.obterNo(10).getInfo());
    }

    @Test
    public void testObterComprimento01() {
        lista = new ListaEncadeada<>();
        Assert.assertEquals(0, lista.obterComprimento());
    }

    @Test
    public void testObterComprimento02() {
        lista = new ListaEncadeada<>();
        lista.inserir(new String("5"));
        lista.inserir(new String("10"));
        lista.inserir(new String("15"));
        lista.inserir(new String("20"));
        Assert.assertEquals(4, lista.obterComprimento());
    }
}
