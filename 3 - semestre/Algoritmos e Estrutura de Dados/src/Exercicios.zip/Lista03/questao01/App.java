package Lista03.questao01;

public class App {
    public static void main(String[] args) {
        ListaEncadeada<String> lista = new ListaEncadeada<>();

        lista.inserir(new String("5"));
        lista.inserir(new String("3"));
        lista.inserir(new String("9"));

        lista.exibir();
    }
}
