package Lista02.testeQuestao01;

import org.junit.Assert;
import org.junit.Test;

import Lista02.questao01.ListaEstatica;
import Lista02.questao01.Numero;

public class ListaEstaticaTest {
    
    @Test
    public void testInverter01() {
        ListaEstatica<Numero> lista = new ListaEstatica<>();
        lista.inserir(new Numero(5));
        lista.inserir(new Numero(10));
        lista.inserir(new Numero(15));
        lista.inserir(new Numero(20));

        lista.inverter();

        Assert.assertEquals("20,15,10,5", lista.toString());
    }

    @Test
    public void testInverter02() {
        ListaEstatica<Numero> lista = new ListaEstatica<>();
        lista.inserir(new Numero(5));
        lista.inserir(new Numero(10));
        lista.inserir(new Numero(15));
        lista.inserir(new Numero(20));
        lista.inserir(new Numero(25));

        lista.inverter();

        Assert.assertEquals("25,20,15,10,5", lista.toString());
    }
}
