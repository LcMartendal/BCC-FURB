package Lista02.questao01;

public class ListaEstatica2<T> {

    private Object[] info;
    private int tamanho;

    public ListaEstatica2() {
        this.info = new Object[10];
        this.tamanho = 0;
    }

    private void redimensionar(){
        Object[] vtRedimensionado = new Object[info.length + 10];
        for(int i=0;i<info.length;i++){
            vtRedimensionado[i] = info[i];
        }

        this.info = vtRedimensionado;
    }

    public void inserir(T valor){
        if(tamanho >= info.length){
            redimensionar();
        }
        info[tamanho] = valor;
        tamanho++;
    }

    public void exibir(){
        for(int i=0;i<tamanho;i++){
            System.out.println(info[i]);
        }
    }

    public int buscar(T valor){
        for(int i=0;i<tamanho;i++){
            if(info[i] == valor){
                return i;
            }
        }
        return -1;
    }

    public void retirar(T valor){
        int posicao = buscar(valor);
        for(int i=posicao;i<tamanho;i++){
            info[i] = info[i + 1];
        }
        tamanho--;
        info[tamanho] = null;
    }

    public void liberar(){
        this.info = new Object[10];
        tamanho = 0;
    }

    @SuppressWarnings("unchecked")
    public T obterElemento(int posicao){
        return (T) info[posicao];
    }

    public boolean estaVazia(){
        if(tamanho == 0){
            return true;
        }
        return false;
    }

    public int getTamanho(){
        return this.tamanho;
    }

    @Override
    public String toString() {
        String msg = "";
        for(int i=0;i<tamanho;i++){
            if(i > 0){
                msg+= ", ";
            }
            msg+= info[i];
        }
        return msg;
    }

    public void inverter(){
        int esquerda = 0;
        int direita = tamanho - 1;
        int qtdTrocas = tamanho/2;
        Object backup;

        while(qtdTrocas > 0){

            backup = info[esquerda];
            info[esquerda] = info[direita];
            info[direita] = backup;

            esquerda++;
            direita--;
            qtdTrocas--;

        } 
    }

    

    
}
