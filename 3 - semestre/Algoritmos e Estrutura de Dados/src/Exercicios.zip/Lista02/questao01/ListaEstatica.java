package Lista02.questao01;

public class ListaEstatica<T> {
    private Object[] info;
    private int tamanho;

    public ListaEstatica() {
        this.info = new Object[10];
        this.tamanho = 0;
    }

    private void redimensionar(){
        Object[] novoVetor = new Object[info.length + 10];
        
        for(int i = 0; i < info.length; i++){
            novoVetor[i] = this.info[i];
        }

        this.info = novoVetor;

    }

    public void inserir(T valor){
        if(this.tamanho < this.info.length){
            this.info[tamanho] = valor; 
            tamanho++;                            
        }else{
            redimensionar();
            this.info[tamanho] = valor;
            tamanho++;
        }
    }

    public void exibir(){
        for(int i = 0; i < tamanho; i++){
            System.out.println(info[i]);
        }
    }

    public int buscar(T valor){
        for(int i = 0; i < tamanho; i++){
            if(this.info[i].equals(valor)){
                return i;   
            }
        }
        return -1;
    }

    public void retirar(T valor){
        int posicao = buscar(valor);
        if (posicao > -1) {
            for (int i = posicao; i < tamanho - 1; i++) {
                info[i] = info[i + 1];
            }

            info[tamanho] = null;
            tamanho--;
        }
    }

    public void libera(){
        this.info = new Object[10];
        tamanho = 0;
    }

    @SuppressWarnings("unchecked")
    public T obterElemento(int posicao){
        if(posicao < 0 || posicao > tamanho){
            throw new IndexOutOfBoundsException("Posicao invalida!");
        }
        return (T)info[posicao];
    }

    public boolean estaVazia(){
        return tamanho == 0;
    }

    public int getTamanho() {
        return tamanho;
    }

    @Override
    public String toString() {
       
        String resultado = "";

        for(int i = 0; i < tamanho; i++){
            if(i > 0){
                resultado += ",";
            }

            resultado += String.valueOf(info[i]);
        }

        return resultado;
    }

    public void inverter(){
        int esquerda = 0;
        int direita = tamanho - 1;
        
        while (esquerda < direita) {
            // Troca os elementos nas posições esquerda e direita
            Object temp = info[esquerda];
            info[esquerda] = info[direita];
            info[direita] = temp;
            
            // Move os índices para o centro
            esquerda++;
            direita--;
        }
        
    }

    
}

