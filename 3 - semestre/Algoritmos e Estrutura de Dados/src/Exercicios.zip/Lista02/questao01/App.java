package Lista02.questao01;

public class App {
    public static void main(String[] args) {
    /*
        ListaEstatica2<Numero> l2 = new ListaEstatica2<>();

        l2.inserir(new Numero(8));
        l2.inserir(new Numero(3));
        l2.inserir(new Numero(1));
        l2.inserir(new Numero(4));
        l2.inserir(new Numero(9));
        l2.inserir(new Numero(2));

        System.out.println("-----------NORMAL-------------");
        l2.exibir();
        System.out.println("-----------INVERTIDO-------------");
        l2.inverter();
        l2.exibir();
        System.out.println("-----------BUSCAR-------------");
        
        System.out.println("-----------TOSTRING-------------");
        System.out.println(l2.toString());
*/
    }
}
