package Lista11.questao01;

public abstract class BuscaAbstract {
    private Object[] info;

    public Object[] getInfo() {
        return info;
    }

    public void setInfo(Object[] info) {
        this.info = info;
    }
}
