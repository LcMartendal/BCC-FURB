package Lista10.questao01;

public class OrdenacaoQuickSort<T extends Comparable<T>> extends OrdenacaoAbstract<T> {

    @Override
    public void ordenar() {
        quickSort(0, getInfo().length - 1);
    }

    private void quickSort(int inicio, int fim) {
        if (inicio < fim) {
            int idxPivo = particionar(inicio, fim);
            quickSort(inicio, idxPivo);
            quickSort(idxPivo + 1, fim);
        }
    }

    private int particionar(int inicio, int fim) {
        T[] vetor = getInfo();
        T pivo = vetor[inicio];
        int i = inicio - 1;
        int j = fim + 1;

        while (true) {
            // Decrementa j até encontrar elemento menor ou igual ao pivô
            do {
                j--;
            } while (vetor[j].compareTo(pivo) > 0);

            // Incrementa i até encontrar elemento maior ou igual ao pivô
            do {
                i++;
            } while (vetor[i].compareTo(pivo) < 0);

            // Se os índices se cruzaram, retorna j (posição final da partição)
            if (i >= j) {
                return j;
            }

            // Troca elementos fora do lugar
            trocar(i, j);
        }
    }

    /*
    @Override
    public void ordenar() {
        quickSort(0, getInfo().length - 1);
    }

    private void quickSort(int inicio, int fim) {
        if (inicio < fim) {
            int posicaoPivo = particionar(inicio, fim);
            quickSort(inicio, posicaoPivo - 1);
            quickSort(posicaoPivo + 1, fim);
        }
    }

    private int particionar(int inicio, int fim) {
        // Define o índice do meio como pivô
        int meio = (inicio + fim) / 2;
        
        // Troca o pivô com o elemento inicial para reaproveitar o algoritmo tradicional
        trocar(inicio, meio);

        T pivo = getInfo()[inicio];
        int i = inicio + 1;
        int f = fim;

        while (i <= f) {
            while (i <= fim && getInfo()[i].compareTo(pivo) <= 0) {
                i++;
            }
            while (getInfo()[f].compareTo(pivo) > 0) {
                f--;
            }
            if (i < f) {
                trocar(i, f);
            }
        }

        trocar(inicio, f);
        return f;
    }
}
     */
}

