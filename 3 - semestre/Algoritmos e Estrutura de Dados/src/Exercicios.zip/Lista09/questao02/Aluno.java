package Lista09.questao02;

import java.time.LocalDate;

public class Aluno {
    private int matricula;
    private String nome;
    private LocalDate dataAniversario;

    public Aluno(int matricula, String nome, LocalDate dataAniversario) {
        this.matricula = matricula;
        this.nome = nome;
        this.dataAniversario = dataAniversario;
    }

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public LocalDate getDataAniversario() {
        return dataAniversario;
    }

    public void setDataAniversario(LocalDate dataAniversario) {
        this.dataAniversario = dataAniversario;
    }

    
}
