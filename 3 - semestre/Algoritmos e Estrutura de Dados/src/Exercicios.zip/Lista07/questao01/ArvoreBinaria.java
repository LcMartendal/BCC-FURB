package Lista07.questao01;

public class ArvoreBinaria<T> {
    private NoArvoreBinaria<T> raiz;

    public ArvoreBinaria(){
        raiz = null;
    }

    public void setRaiz(NoArvoreBinaria<T> raiz) {
        this.raiz = raiz;
    }

    public boolean estaVazia(){
        return raiz == null;
    }

    public boolean pertence(T info){
        return pertence(raiz, info);

    }

    private boolean pertence(NoArvoreBinaria<T> no, T info){
        if(no == null){
            return false;
        }

        return (no.getInfo().equals(info)) || pertence(no.getEsquerda(), info) || (pertence(no.getDireita(), info));

    }

    public String toString(){
        return arvorePre(raiz);
    }

    private String arvorePre(NoArvoreBinaria<T> no){
        String retorno = "";

        if(no == null){
            retorno+= "<>";
        }else{
            retorno+= "<" + no.getInfo() + arvorePre(no.getEsquerda()) + arvorePre(no.getDireita()) + ">";
        }
        return retorno;
    }

    public int contarNos(){
        return contarNos(raiz);
    }

    private int contarNos(NoArvoreBinaria<T> no){
        int qtdnos = 0;
        if(no != null){
            qtdnos = 1 + contarNos(no.getEsquerda()) + contarNos(no.getDireita());
        }

        return qtdnos;
    }
}
