package Lista07.testeQuestao01;
import static org.junit.Assert.assertEquals;

import org.junit.Test;

import Lista07.questao01.ArvoreBinaria;
import Lista07.questao01.NoArvoreBinaria;

public class ArvoreBinariaTest {
    @Test
    public void test1() {
        ArvoreBinaria<Integer> arvore = new ArvoreBinaria<>();

        assertEquals(true, arvore.estaVazia());
    }

    @Test
    public void test2() {
        ArvoreBinaria<Integer> arvore = new ArvoreBinaria<>();
        NoArvoreBinaria<Integer> no1 = new NoArvoreBinaria<Integer>(5);
        arvore.setRaiz(no1);

        assertEquals(false, arvore.estaVazia());
    }

    @Test
    public void test3() {
        ArvoreBinaria<Integer> arvore = new ArvoreBinaria<>();
        NoArvoreBinaria<Integer> no6 = new NoArvoreBinaria<>(6);
        arvore.setRaiz(no6);
        NoArvoreBinaria<Integer> no5 = new NoArvoreBinaria<>(5);
        arvore.setRaiz(no5);
        NoArvoreBinaria<Integer> no4 = new NoArvoreBinaria<>(4);
        arvore.setRaiz(no4);
        NoArvoreBinaria<Integer> no3 = new NoArvoreBinaria<>(3, no5, no6);
        arvore.setRaiz(no3);
        NoArvoreBinaria<Integer> no2 = new NoArvoreBinaria<>(2, null, no4);
        arvore.setRaiz(no2);
        NoArvoreBinaria<Integer> no1 = new NoArvoreBinaria<>(1, no2, no3);
        arvore.setRaiz(no1);

        assertEquals("<1<2<><4<><>>><3<5<><>><6<><>>>>", arvore.toString());
    }

    @Test
    public void test4() {
        ArvoreBinaria<Integer> arvore = new ArvoreBinaria<>();
        NoArvoreBinaria<Integer> no6 = new NoArvoreBinaria<>(6);
        arvore.setRaiz(no6);
        NoArvoreBinaria<Integer> no5 = new NoArvoreBinaria<>(5);
        arvore.setRaiz(no5);
        NoArvoreBinaria<Integer> no4 = new NoArvoreBinaria<>(4);
        arvore.setRaiz(no4);
        NoArvoreBinaria<Integer> no3 = new NoArvoreBinaria<>(3, no5, no6);
        arvore.setRaiz(no3);
        NoArvoreBinaria<Integer> no2 = new NoArvoreBinaria<>(2, null, no4);
        arvore.setRaiz(no2);
        NoArvoreBinaria<Integer> no1 = new NoArvoreBinaria<>(1, no2, no3);
        arvore.setRaiz(no1);

        assertEquals(true, arvore.pertence(1));
    }

    @Test
    public void test5() {
        ArvoreBinaria<Integer> arvore = new ArvoreBinaria<>();
        NoArvoreBinaria<Integer> no6 = new NoArvoreBinaria<>(6);
        arvore.setRaiz(no6);
        NoArvoreBinaria<Integer> no5 = new NoArvoreBinaria<>(5);
        arvore.setRaiz(no5);
        NoArvoreBinaria<Integer> no4 = new NoArvoreBinaria<>(4);
        arvore.setRaiz(no4);
        NoArvoreBinaria<Integer> no3 = new NoArvoreBinaria<>(3, no5, no6);
        arvore.setRaiz(no3);
        NoArvoreBinaria<Integer> no2 = new NoArvoreBinaria<>(2, null, no4);
        arvore.setRaiz(no2);
        NoArvoreBinaria<Integer> no1 = new NoArvoreBinaria<>(1, no2, no3);
        arvore.setRaiz(no1);

        assertEquals(true, arvore.pertence(3));
    }

    @Test
    public void test6() {
        ArvoreBinaria<Integer> arvore = new ArvoreBinaria<>();
        NoArvoreBinaria<Integer> no6 = new NoArvoreBinaria<>(6);
        arvore.setRaiz(no6);
        NoArvoreBinaria<Integer> no5 = new NoArvoreBinaria<>(5);
        arvore.setRaiz(no5);
        NoArvoreBinaria<Integer> no4 = new NoArvoreBinaria<>(4);
        arvore.setRaiz(no4);
        NoArvoreBinaria<Integer> no3 = new NoArvoreBinaria<>(3, no5, no6);
        arvore.setRaiz(no3);
        NoArvoreBinaria<Integer> no2 = new NoArvoreBinaria<>(2, null, no4);
        arvore.setRaiz(no2);
        NoArvoreBinaria<Integer> no1 = new NoArvoreBinaria<>(1, no2, no3);
        arvore.setRaiz(no1);

        assertEquals(true, arvore.pertence(6));
    }

    @Test
    public void test7() {
        ArvoreBinaria<Integer> arvore = new ArvoreBinaria<>();
        NoArvoreBinaria<Integer> no6 = new NoArvoreBinaria<>(6);
        arvore.setRaiz(no6);
        NoArvoreBinaria<Integer> no5 = new NoArvoreBinaria<>(5);
        arvore.setRaiz(no5);
        NoArvoreBinaria<Integer> no4 = new NoArvoreBinaria<>(4);
        arvore.setRaiz(no4);
        NoArvoreBinaria<Integer> no3 = new NoArvoreBinaria<>(3, no5, no6);
        arvore.setRaiz(no3);
        NoArvoreBinaria<Integer> no2 = new NoArvoreBinaria<>(2, null, no4);
        arvore.setRaiz(no2);
        NoArvoreBinaria<Integer> no1 = new NoArvoreBinaria<>(1, no2, no3);
        arvore.setRaiz(no1);

        assertEquals(false, arvore.pertence(10));
    }

    @Test
    public void test8() {
        ArvoreBinaria<Integer> arvore = new ArvoreBinaria<>();
        NoArvoreBinaria<Integer> no6 = new NoArvoreBinaria<>(6);
        arvore.setRaiz(no6);
        NoArvoreBinaria<Integer> no5 = new NoArvoreBinaria<>(5);
        arvore.setRaiz(no5);
        NoArvoreBinaria<Integer> no4 = new NoArvoreBinaria<>(4);
        arvore.setRaiz(no4);
        NoArvoreBinaria<Integer> no3 = new NoArvoreBinaria<>(3, no5, no6);
        arvore.setRaiz(no3);
        NoArvoreBinaria<Integer> no2 = new NoArvoreBinaria<>(2, null, no4);
        arvore.setRaiz(no2);
        NoArvoreBinaria<Integer> no1 = new NoArvoreBinaria<>(1, no2, no3);
        arvore.setRaiz(no1);

        assertEquals(6, arvore.contarNos());
    }


}
