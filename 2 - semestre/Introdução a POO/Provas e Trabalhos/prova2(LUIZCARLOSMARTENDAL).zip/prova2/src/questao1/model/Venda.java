/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package questao1.model;

import java.util.ArrayList;

/**
 *
 * @author Lc Martendal
 */
public class Venda {
    
    private ArrayList<Produto> produtos = new ArrayList<>();
    
    
    private Cliente cliente;
    private Vendedor vendedor;
    private TipoEntrega tipoEntrega;

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Vendedor getVendedor() {
        return vendedor;
    }

    public void setVendedor(Vendedor vendedor) {
        this.vendedor = vendedor;
    }

    public TipoEntrega getTipoEntrega() {
        return tipoEntrega;
    }

    public void setTipoEntrega(TipoEntrega tipoEntrega) {
        this.tipoEntrega = tipoEntrega;
    }
    
    
    
    public void inserirProduto(Produto p){
        if(produtos.size() <= 10){
        produtos.add(p);
        }else 
            throw new IllegalArgumentException("Numero maximo de produtos atingido!");
    }

    public ArrayList<Produto> getProdutos() {
        return produtos;
    }
    
    public double calcularValorEntrega(){
        int pesoTotal = 0;
        for(Produto p: produtos){
            pesoTotal+= p.getPeso();
        }
        if(tipoEntrega.equals(tipoEntrega.RETIRADA_LOCAL)){
            return 0;
        }else if(tipoEntrega.equals(tipoEntrega.SEDEX)){
            
            return 15 + (0.045 * pesoTotal); 
        }else if(tipoEntrega.equals(tipoEntrega.ENCOMENDA_PAC)){
            return 9.75;
        }else if(tipoEntrega.equals(null)){
            throw new IllegalArgumentException("Tipo de entrega nao definido!");
        }
        return 0;
    }
    
    public double calcularValorProdutos(){
        double valorTotal = 0;
        
        for(Produto p: produtos){
            valorTotal+= p.getValor();
        }
        if(produtos.size() == 0){
            throw new IllegalArgumentException("Nao ha produtos cadastrados!");
        }else if(cliente.equals(null)){
            throw new IllegalArgumentException("Nao ha cliente definido!");
        }else if(cliente.isMesAniversario() == true){
            return valorTotal - ((valorTotal * 8)/100);
        }else 
            return valorTotal;
    }
    
    public double calcularComissao(){
        double valorTotal = 0;
        
        if(vendedor.equals(null)){
            throw new IllegalArgumentException("Vendedor nao definido!");
        }
        for(Produto p: produtos){
            valorTotal+= p.getValor();
        }
        
        return valorTotal * vendedor.getPercentualComissao();
        
        
    }
}
