/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;

/**
 *
 * @author Lc Martendal
 */
public class ImportadorUrna {
    private Map<Chapa, Integer> votos;
    private File arquivo;

    public ImportadorUrna() {
        votos = new HashMap<>();
    }

    public void setArquivo(File arquivo) {
        this.arquivo = arquivo;
    }
    
    public void processarArquivo() throws FileNotFoundException{
        try(Scanner scan = new Scanner(arquivo)){
            scan.nextLine();
            
            while(scan.hasNextLine()){
                String[] linha = scan.nextLine().split(";");
                
                Chapa chapa = new Chapa();
                chapa.setIdentificacao(linha[0]);
                chapa.setNome(linha[1]);
                chapa.setPresidente(linha[2]);
                chapa.setCursoPresidente(linha[3]);
                chapa.setVicePresidente(linha[4]);
                chapa.setCursoVicePresidente(linha[5]);
                
                Integer qtdVotos = votos.get(chapa);
                
                if(votos.containsKey(chapa)){
                    votos.put(chapa, Integer.parseInt(linha[6]) + qtdVotos);
                }
                else{
                    votos.put(chapa, Integer.parseInt(linha[6]));
                }

            }
        }
    }

    public Map<Chapa, Integer> getVotos() {
        return votos;
    }
    
    public int obterTotalVotos(){
        int totalDeVotos = 0;
        for(int quantidadeVotos : votos.values()){
            totalDeVotos += quantidadeVotos;
        }
        return totalDeVotos;
        
    }
    
    public Entry<Chapa, Integer> obterChapaVencedora(){
        Map.Entry<Chapa, Integer> maiorVoto = null;
        for(Map.Entry<Chapa, Integer> qtd : votos.entrySet()){
            if(maiorVoto == null){
                maiorVoto = qtd;
            }else if(qtd.getValue() > maiorVoto.getValue()){
                maiorVoto = qtd;
            }
        }
        return maiorVoto;
    }
}
