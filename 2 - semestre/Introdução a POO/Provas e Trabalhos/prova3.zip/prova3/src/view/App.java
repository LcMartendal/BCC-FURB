/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import java.io.File;
import java.io.FileNotFoundException;
import java.text.DecimalFormat;
import java.util.Map;
import java.util.Scanner;
import model.Chapa;
import model.ImportadorUrna;

/**
 *
 * @author Lc Martendal
 */
public class App {
    public static void main(String[] args) throws FileNotFoundException {
        Scanner scan = new Scanner(System.in);
        ImportadorUrna i = new ImportadorUrna();
        
        System.out.print("Informe o caminho do arquivo csv com os dados das urnas:");
        String nomeArquivo = scan.next();
        
        i.setArquivo(new File(nomeArquivo));
        
        i.processarArquivo();
        
        System.out.println("***** Relacao de votos por chapa *****");
        for(Map.Entry<Chapa, Integer> dados : i.getVotos().entrySet()){
            System.out.println("---------------------------------------------------------------------------------------------");
            System.out.println(dados.getKey().getIdentificacao() + " - " + dados.getKey().getNome() + " - Total de votos: " + dados.getValue());
            System.out.println(">> Presidente: " + dados.getKey().getPresidente() + " Curso: " + dados.getKey().getCursoPresidente()); 
            System.out.println(">> Vice: " + dados.getKey().getVicePresidente() + " Curso: " + dados.getKey().getCursoVicePresidente()); 
            System.out.println("---------------------------------------------------------------------------------------------");
        }
        
        System.out.println("***** TOTALIZACOES *****");
        System.out.println("Total geral de votos: " + i.obterTotalVotos());
        DecimalFormat df = new DecimalFormat("0.00");
        double percVotos = (i.obterChapaVencedora().getValue() * 100) / i.obterTotalVotos();
        System.out.println("A chapa vencedora foi: " + i.obterChapaVencedora().getKey().getIdentificacao() + "(" 
                + i.obterChapaVencedora().getKey().getNome() + ") com: " 
                + i.obterChapaVencedora().getValue() + " votos representando " + df.format(percVotos) + " do total de votos." );
        
        
    }
}
