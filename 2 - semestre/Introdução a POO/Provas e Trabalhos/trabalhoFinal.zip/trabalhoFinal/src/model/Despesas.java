/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.text.DecimalFormat;
import java.time.LocalDate;

/**
 *
 * @author Lc Martendal
 */
public class Despesas extends Movimentos{

    DecimalFormat df = new DecimalFormat("0.00");
    
    public Despesas(String descricao, double valor, LocalDate data) {
        super(descricao, valor, data);
    }

    public Despesas() {
    }

    @Override
    public String tipoMovimento() {
        return "Despesa";
    }

}
