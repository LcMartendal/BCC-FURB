/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.awt.List;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Lc Martendal
 */
public class GestaoReceitasDespesas implements Consulta_de_saldo, Listar_movimentos{
    
    DecimalFormat df = new DecimalFormat("0.00");
    ArrayList<Movimentos> movimento = new ArrayList<>();
    File arqCSV = new File(".//ArquivoGestaoReceitasEDespesas.csv");
    
    /**
     * Esse metodo inclui para o arraylist os movimentos desejados.
     * @param m NO parametro é passsado o movimento realizado (receita/despesa).
     */
    public void incluirMovimento(Movimentos m){
        this.movimento.add(m);
    }

    public ArrayList<Movimentos> getMovimento() {
        return movimento;
    }
    
    /**
     * Nesse metodo é possivel consultar o saldo atual, ou seja, até a data atual.
     * @return Retorna o saldo atual da pessoa.
     */
    @Override
    public double consultarSaldoAtual() {
        double saldo = 0;
        LocalDate hoje = LocalDate.now();
        for(Movimentos m : movimento){
            if(m.getData().isBefore(hoje) || m.getData().isEqual(hoje)){
                if(m.tipoMovimento().equals("Receita")){
                    saldo += m.getValor();
                }else if(m.tipoMovimento().equals("Despesa")){
                    saldo -= m.getValor();
                }
            }
        }
        
        return saldo;
    }
    
    /**
     * Nesse metodo podemos consultar o saldo total, aqui nesse metodo não importa a data, o saldo vai sofrer as alterações 
     * até por movimentos futuros.
     * @return Retorna o saldo total da pessoa.
     */
    @Override
    public double consultarSaldoTotal() {
        double saldo = 0;
        for(Movimentos m : movimento){
            if(m.tipoMovimento().equals("Receita")){
                saldo += m.getValor();
            }else if(m.tipoMovimento().equals("Despesa")){
                saldo -= m.getValor();
            }
        }
        
        return saldo;
    }
    
    /**
     * Esse metodo cria outro arraylist para armazenar somente receitas.
     * @return Retorna um arraylist com os movimentos que são do tipo "receita".
     */
    @Override
    public ArrayList<Movimentos> listarMovimentoTipoReceitas() {
        ArrayList<Movimentos> receita = new ArrayList<>();
        for(Movimentos r : movimento){
            if(r.tipoMovimento().equals("Receita")){
                receita.add(r);
            }
        }
        return receita;
    }
    
    /**
     * Esse metodo cria outro arraylist para armazenar somente despesas.
     * @return Retorna um arraylist com os movimentos que são do tipo "despesa".
     */
    @Override
    public ArrayList<Movimentos> listarMovimentoTipoDespesas() {
        ArrayList<Movimentos> despesa = new ArrayList<>();
        for(Movimentos d : movimento){
            if(d.tipoMovimento().equals("Despesa")){
                despesa.add(d);
            }
        }
        return despesa;
    }
    
    /**
     * Esse metodo usa o collections.sort para ordenar, por data, o arraylist com todos movimentos, independente do tipo.
     * @return Retorna o arraylist movimentos ordenado por data.
     */
    @Override
    public ArrayList<Movimentos> listarTodosMovimentosOrdenadosPorData() {
        Collections.sort(movimento, new OrdenamentoPorData());
        return movimento;
    }

    /**
     * Nesse metodo salvo os dados dos movimentos para um arquivo, 
     * Quando chamar esse metodo, ele criara um arquivo CSV na pasta que está salva o projeto
     * Se ja houver um movimento feito, o cabeçalho não será inserindo.
     */
    public void salvarDados(){
        restauraArquivo();
        
        try(BufferedWriter writer = new BufferedWriter(new FileWriter(arqCSV, true ))){ 
            if(arqCSV.length() == 0){
                writer.write("Categoria;Valor;Data;Tipo\n");
                
            }
            for(Movimentos m : this.movimento){
                    writer.write(m.getDescricao() + ";" + m.getValor() + ";" + m.getData() + ";" + m.tipoMovimento() + ";");
                    writer.newLine();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    /*
    Esse metodo restaura o arquivo, deixando ele em branco
    */
    public void restauraArquivo(){
        File arqCSV = new File(".//ArquivoGestaoReceitasEDespesas.csv");
        try (FileWriter writer = new FileWriter(arqCSV, false)) {
                // Sobrescreve o arquivo com conteúdo vazio
                writer.write("");
                
            } catch (IOException e) {
                
            }
        }
    /**
     * Esse metodo le o arquivo CSV, se ele existir. Se existir e houver algo nele, ele irá adicionar para o arraylist
     * os movimentos guardados no arquivo
     * @return Retorna o arraylist "movimentos" com os movimentos presentes no arquivo CSV
     */
    public ArrayList<Movimentos> carregarDados(){
        try(BufferedReader reader = new BufferedReader(new FileReader(arqCSV))){
            String linha;
            reader.readLine(); // Lê e descarta a primeira linha
            while((linha = reader.readLine()) != null){
                String[] partes = linha.split(";");
                String descricao = partes[0];
                Double valor = Double.parseDouble(partes[1]);
                LocalDate data = LocalDate.parse(partes[2]);
                String tipo = partes[3];
                
                if(tipo.equals("Receita")){
                    movimento.add(new Receitas(descricao, valor, data));
                }else if(tipo.equals("Despesa")){
                    movimento.add(new Despesas(descricao, valor, data));
                }
            }
            
            if(movimento.isEmpty()){
                System.out.println("Não há nada incluso!");
            }
        } catch (FileNotFoundException e){
            System.out.println("Arquivo não encontrado!");
        } catch (IOException e) {
            System.out.println("Erro ao ler o arquivo!");
        }
        
        return movimento;
    }

    
    
}
