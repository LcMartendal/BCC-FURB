/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.text.DecimalFormat;
import java.time.LocalDate;
import javax.swing.JOptionPane;
import javax.swing.plaf.RootPaneUI;

/**
 *
 * @author Lc Martendal
 */
public class Movimentos{
        
    private String descricao;
    private double valor;
    private LocalDate data;
    private String tipoMovimento;    

    public Movimentos(String descricao, double valor, LocalDate data) {
        this.descricao = descricao;
        this.valor = valor;
        this.data = data;
    }

    public Movimentos() {
    }

    public String getDescricao() {
        return descricao;
    }

    public void setCategoria(String descricao) {
        if(descricao == null){
            throw new IllegalArgumentException("Categoria não informada!");
        }
        this.descricao = descricao;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        if(valor < 0){
            throw new IllegalArgumentException("Valor informado não é aceitavel!");
        }
        this.valor = valor;
    }

    public LocalDate getData() {
        return data;
    }

    public void setData(LocalDate data) {
        this.data = data;
    }

    /** 
     * Define o tipo de movimento.
     * @return Retorna o tipo de movimento em forma de String.
     */
    public String tipoMovimento() {
        return tipoMovimento;
    }
    
}
