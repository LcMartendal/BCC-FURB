/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import java.text.DecimalFormat;
import java.time.LocalDate;
import model.Despesas;
import model.GestaoReceitasDespesas;
import model.Movimentos;
import model.Receitas;

/**
 *
 * @author Lc Martendal
 */
public class App {
    public static void main(String[] args) {
        GestaoReceitasDespesas pessoa = new GestaoReceitasDespesas();
        
        Receitas[] r = new Receitas[5];
        Despesas[] d = new Despesas[5];
        
     /*
        r[0] = new Receitas("Salario", 1000, LocalDate.now());
        r[1] = new Receitas("Decimo terceiro", 500, LocalDate.of(2024, 10, 03));
        r[2] = new Receitas("FGTS", 700, LocalDate.now());
        r[3] = new Receitas("FGTS", 5000, LocalDate.of(2024, 12, 03));
        
        d[0] = new Despesas("Alimentacao", 200, LocalDate.of(2024, 12, 07));
        d[1] = new Despesas("Alimentacao", 100, LocalDate.now());
        d[2] = new Despesas("Alimentacao", 50, LocalDate.now());
        d[3] = new Despesas("Alimentacao", 50, LocalDate.of(2024, 10, 01));
        
        pessoa.addMovimento(r[0]);
        pessoa.addMovimento(r[1]);
        pessoa.addMovimento(r[2]);
        pessoa.addMovimento(r[3]);
        pessoa.addMovimento(d[0]);
        pessoa.addMovimento(d[1]);
        pessoa.addMovimento(d[2]);
        pessoa.addMovimento(d[3]);
        
        pessoa.salvarDados();
        */pessoa.carregarDados();
        
        System.out.println("-----RECEITAS-------\n");
        System.out.println("Categoria, valor, data, tipo de movimento");
        for(Movimentos receita : pessoa.listarMovimentoTipoReceitas()){
            System.out.println("" + receita.getDescricao());
        }
        System.out.println("");
        System.out.println("-------DESPESA---------\n");
        System.out.println("Categoria, valor, data, tipo de movimento");
        pessoa.listarMovimentoTipoDespesas();
        System.out.println("");
        System.out.println("-------MOVIMENTOS-------\n");
        System.out.println("Categoria, valor, data, tipo de movimento");
        pessoa.listarTodosMovimentosOrdenadosPorData();
        System.out.println("");
        DecimalFormat df = new DecimalFormat("0.00");
        System.out.println("Saldo atual = " + df.format(pessoa.consultarSaldoAtual()));
        System.out.println("Saldo total = " + df.format(pessoa.consultarSaldoTotal()));
        
    }
}
