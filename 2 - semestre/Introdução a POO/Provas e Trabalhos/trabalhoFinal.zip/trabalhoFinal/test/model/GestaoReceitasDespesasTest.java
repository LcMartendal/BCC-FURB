/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package model;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;

/**
 *
 * @author Lc Martendal
 */
public class GestaoReceitasDespesasTest {
    
    public GestaoReceitasDespesasTest() {
    }
    
    GestaoReceitasDespesas gestao;
    Movimentos movimento;
    Movimentos despesa;
    Movimentos receita;
    Movimentos despesa_;
    Movimentos receita_;
    ArrayList<Movimentos> guardaDadosUsados;
    
    @Test
    public void testSomeMethod() {
    }
    
    @Before
    public void incializarContexto(){
        gestao = new GestaoReceitasDespesas();
        movimento = new Movimentos();
        despesa = new Despesas();
        receita = new Receitas();
        despesa_ = new Despesas();
        receita_ = new Receitas();
        guardaDadosUsados = new ArrayList<>();

    }
    @Test
    public void test1IncluirMovimento() {
        
        despesa.setCategoria("Alimentacao");
        despesa.setValor(600);
        despesa.setData(LocalDate.of(2024, 11, 18));
        
        receita.setCategoria("Salario");
        receita.setValor(800);
        receita.setData(LocalDate.of(2024, 11, 18));
        
        gestao.incluirMovimento(despesa);
        gestao.incluirMovimento(receita);
        
        assertEquals(2, gestao.movimento.size());
        
        Movimentos movimento1 = gestao.movimento.get(0);

        assertEquals("Verificando se o tipo de movimento está condizente",despesa.tipoMovimento(), movimento1.tipoMovimento());
        assertEquals("Verificando se o tipo de movimento está condizente",600, movimento1.getValor(), 0.01);
        
        Movimentos movimento2 = gestao.movimento.get(1);

        assertEquals("Verificando se o tipo de movimento está condizente",receita.tipoMovimento(), movimento2.tipoMovimento());
        assertEquals("Verificando se o tipo de movimento está condizente",800, movimento2.getValor(), 0.01);
        
    }
    
    @Test
    public void test2SaldoTotal() {
        
        receita = new Receitas("Salario", 600, LocalDate.of(2024, 11, 19));
        despesa = new Despesas("Alimentacao", 400, LocalDate.of(2025, 11, 19));
        
        gestao.incluirMovimento(receita);
        gestao.incluirMovimento(despesa);
        assertEquals(200, gestao.consultarSaldoTotal(), 0.01);
    }
    
    @Test
    public void test3SaldoAtual() {
        
        receita = new Receitas("Salario", 600, LocalDate.of(2024, 11, 19));
        despesa = new Despesas("Alimentacao", 400, LocalDate.of(2025, 11, 19));
        receita_ = new Receitas("Decimo", 1200, LocalDate.of(2024, 11, 27));
        despesa_ = new Despesas("Carro", 800, LocalDate.of(2023, 11, 19));
        
        gestao.incluirMovimento(receita);
        gestao.incluirMovimento(despesa);
        gestao.incluirMovimento(receita_);
        gestao.incluirMovimento(despesa_);
        assertEquals(-200, gestao.consultarSaldoAtual(), 0.01);
    }
    
    @Test
    public void test4ListandoReceitas() {
        
        receita = new Receitas("Salario", 600, LocalDate.of(2024, 11, 19));
        despesa = new Despesas("Alimentacao", 400, LocalDate.of(2025, 11, 19));
        receita_ = new Receitas("Decimo", 1200, LocalDate.of(2024, 11, 27));
        despesa_ = new Despesas("Carro", 800, LocalDate.of(2023, 11, 19));
        
        gestao.incluirMovimento(receita);
        gestao.incluirMovimento(despesa);
        gestao.incluirMovimento(receita_);
        gestao.incluirMovimento(despesa_);
        
        assertEquals(2, gestao.listarMovimentoTipoReceitas().size());
    }
    
    @Test
    public void test5ListandoReceitas() {
        
        receita = new Receitas("Salario", 600, LocalDate.of(2024, 11, 19));
        despesa = new Despesas("Alimentacao", 400, LocalDate.of(2025, 11, 19));
        receita_ = new Receitas("Decimo", 1200, LocalDate.of(2024, 11, 27));
        despesa_ = new Despesas("Carro", 800, LocalDate.of(2023, 11, 19));
        
        gestao.incluirMovimento(receita);
        gestao.incluirMovimento(despesa);
        gestao.incluirMovimento(receita_);
        
        assertEquals(1, gestao.listarMovimentoTipoDespesas().size());
    }
    
    @Test
    public void test6ListandoTodosMovimentosVerificandoOrdencaoPorData() {
        
        receita = new Receitas("Salario", 600, LocalDate.of(2024, 10, 22));
        despesa = new Despesas("Alimentacao", 400, LocalDate.of(2025, 11, 19));
        receita_ = new Receitas("Decimo", 1200, LocalDate.of(2024, 11, 27));
        despesa_ = new Despesas("Carro", 800, LocalDate.of(2023, 04, 02));
        
        gestao.incluirMovimento(receita);
        gestao.incluirMovimento(despesa);
        gestao.incluirMovimento(receita_);
        gestao.incluirMovimento(despesa_);
        
        assertEquals(4, gestao.listarTodosMovimentosOrdenadosPorData().size());
        
        Movimentos movimento1 = gestao.listarTodosMovimentosOrdenadosPorData().get(0);
        Movimentos movimento2 = gestao.listarTodosMovimentosOrdenadosPorData().get(1);
        Movimentos movimento3 = gestao.listarTodosMovimentosOrdenadosPorData().get(2);
        Movimentos movimento4 = gestao.listarTodosMovimentosOrdenadosPorData().get(3);
        
        assertEquals("", despesa_.tipoMovimento(), movimento1.tipoMovimento());
        assertEquals("", receita.tipoMovimento(), movimento2.tipoMovimento());
        assertEquals("", receita_.tipoMovimento(), movimento3.tipoMovimento());
        assertEquals("", despesa.tipoMovimento(), movimento4.tipoMovimento());
        
    }
    
    @Test
    public void test7SalvarDados() throws IOException {

        File arqCSV = new File(".//ArquivoGestaoReceitasEDespesas.csv");
        
        String tipoMovimento = null;
                
        gestao.carregarDados();
        
        if(arqCSV.exists()){
            try(Scanner sc = new Scanner(arqCSV)){
                while(sc.hasNextLine()){
                    String[] linha = sc.nextLine().split(";");

                    tipoMovimento = linha[3];
                    
                    if(tipoMovimento == "Receiita"){
                        assertEquals("", receita.tipoMovimento(), tipoMovimento);
                    }else if(tipoMovimento == "Despesa"){
                        assertEquals("", despesa.tipoMovimento(), tipoMovimento);
                    }
                }
            }

        }else {
            assertEquals(0, arqCSV.length());
        }
    }
    
    @Test
    public void test8CarregarDados(){

        File arqCSV = new File(".//ArquivoGestaoReceitasEDespesas.csv");
        
        if(arqCSV.exists()){
            gestao.carregarDados();
        
        Movimentos movimento1 = gestao.listarTodosMovimentosOrdenadosPorData().get(0);
        
        if(movimento1.tipoMovimento().equals("Receita")){
            assertEquals("", receita.tipoMovimento(), movimento1.tipoMovimento());
        }else if(movimento1.tipoMovimento().equals("Despesa")){
            assertEquals("", despesa.tipoMovimento(), movimento1.tipoMovimento());
        }
        }else {
            assertEquals(0, arqCSV.length());
        }
        
    }

}
